# StockUI
only HTML and CSS code
